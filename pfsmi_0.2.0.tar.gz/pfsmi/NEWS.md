# pfsmi 0.2.0

* Added `validate_pfsmi_data()` for input checks.
* Added `donor_diagnostics()` for imputation support diagnostics.
* Revised `mi_bicr()` to report Cox pooling as the primary analysis, signed log-rank as secondary, and median PFS summaries descriptively.
* Improved simulation event indicators and visit alignment.
* Added IPCW weight summaries and truncation count.

# pfsmi 0.1.0

* Initial package skeleton for BICR PFS multiple imputation sensitivity analysis.
