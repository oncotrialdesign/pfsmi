library(testthat)
library(pfsmi)
test_check("pfsmi")
