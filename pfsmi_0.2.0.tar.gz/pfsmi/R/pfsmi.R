# pfsmi: Multiple imputation sensitivity analysis for BICR-assessed PFS

.require_cols <- function(data, cols) {
  missing <- setdiff(cols, names(data))
  if (length(missing) > 0L) {
    stop("missing required column(s): ", paste(missing, collapse = ", "), call. = FALSE)
  }
  invisible(TRUE)
}

.check_binary <- function(x, nm) {
  ok <- is.na(x) | x %in% c(0L, 1L, 0, 1)
  if (!all(ok)) stop(nm, " must contain only 0/1 values", call. = FALSE)
  invisible(TRUE)
}

#' Validate a pfsmi analysis data set
#'
#' Checks the minimum columns and value ranges needed by the BICR PFS sensitivity
#' analysis functions.
#'
#' @param data Analysis data frame.
#' @param time_bicr,event_bicr,time_inv,event_inv Column names for BICR and local
#'   investigator times and event indicators.
#' @param arm Treatment arm column name.
#' @return Invisibly returns TRUE if validation succeeds.
#' @export
validate_pfsmi_data <- function(data,
                                time_bicr = "obs_pfs_bicr",
                                event_bicr = "event_bicr",
                                time_inv = "obs_pfs_inv",
                                event_inv = "event_inv",
                                arm = "trt") {
  .require_cols(data, c(time_bicr, event_bicr, time_inv, event_inv, arm))
  for (nm in c(time_bicr, time_inv)) {
    x <- data[[nm]]
    if (!is.numeric(x)) stop(nm, " must be numeric", call. = FALSE)
    if (any(!is.finite(x) | x < 0, na.rm = TRUE)) {
      stop(nm, " must contain finite nonnegative times", call. = FALSE)
    }
  }
  .check_binary(data[[event_bicr]], event_bicr)
  .check_binary(data[[event_inv]], event_inv)
  invisible(TRUE)
}

#' Validate a BICR PFS analysis data set
#'
#' Performs basic column and value checks before running the BICR MI workflow.
#'
#' @param data Analysis data frame.
#' @param required Required column names.
#' @return Invisibly returns TRUE if checks pass.
#' @export
validate_bicr_data <- function(data,
                               required = c("trt", "obs_pfs_inv", "obs_pfs_bicr",
                                            "event_inv", "event_bicr")) {
  .require_cols(data, required)
  time_cols <- intersect(c("obs_pfs_inv", "obs_pfs_bicr", "obs_pfs_bicr_upper",
                           "true_pfs_bicr", "pfs_imputed"), names(data))
  for (nm in time_cols) {
    if (!is.numeric(data[[nm]]) || any(!is.finite(data[[nm]]) | data[[nm]] < 0, na.rm = TRUE)) {
      stop("time column ", nm, " must contain finite nonnegative numeric values", call. = FALSE)
    }
  }
  event_cols <- intersect(c("event_inv", "event_bicr", "event_missing", "event_imputed"), names(data))
  for (nm in event_cols) .check_binary(data[[nm]], nm)
  invisible(TRUE)
}

.first_visit_after <- function(x, visits) {
  visits <- sort(unique(visits))
  vapply(x, function(one) {
    y <- visits[visits >= one]
    if (length(y) == 0L) visits[length(visits)] else y[1L]
  }, numeric(1))
}

.single_arm_bicr <- function(trt, med_inv, med_bicr, rho, n, cutoff,
                             visit_interval, disagreement, stay,
                             visit_jitter_sd) {
  sigma <- matrix(c(1, rho, rho, 1), nrow = 2)
  z <- matrix(stats::rnorm(2 * n), ncol = 2) %*% chol(sigma)
  u <- stats::pnorm(z)
  latent_inv <- stats::qexp(u[, 1], rate = log(2) / med_inv)
  latent_bicr <- stats::qexp(u[, 2], rate = log(2) / med_bicr)

  visits <- seq(visit_interval, cutoff + 10 * visit_interval, by = visit_interval)
  if (!is.null(visit_jitter_sd) && visit_jitter_sd > 0) {
    visits <- visits + stats::rnorm(length(visits), mean = 0, sd = visit_jitter_sd)
    visits <- sort(pmax(visits, 0.01))
  }

  obs_inv_visit <- .first_visit_after(latent_inv, visits)
  obs_bicr_visit <- .first_visit_after(latent_bicr, visits)
  event_inv <- as.integer(obs_inv_visit <= cutoff)
  event_bicr <- as.integer(obs_bicr_visit <= cutoff)
  obs_inv <- ifelse(obs_inv_visit > cutoff, cutoff, obs_inv_visit)
  true_bicr <- ifelse(obs_bicr_visit > cutoff, cutoff, obs_bicr_visit)

  dis <- integer(n)
  if (disagreement > 0) dis[sample.int(n, size = round(n * disagreement))] <- 1L
  obs_bicr <- true_bicr
  is_discordant <- event_inv == 1L & obs_bicr_visit > obs_inv & dis == 1L
  obs_bicr[is_discordant] <- obs_inv[is_discordant]
  event_bicr[is_discordant] <- 0L

  upper <- obs_bicr
  event_missing <- integer(n)
  idx <- which(is_discordant)
  if (length(idx) > 0L) {
    continue <- stats::runif(length(idx)) < stay
    tmp <- obs_bicr_visit[idx] + stats::rnorm(length(idx), mean = visit_interval,
                                             sd = 0.5 * visit_interval)
    tmp <- pmax(tmp, obs_bicr[idx] + visit_interval)
    upper[idx[continue]] <- tmp[continue]
    event_missing[idx[continue]] <- 1L
  }

  data.frame(
    id = seq_len(n), trt = trt,
    obs_pfs_inv = obs_inv, obs_pfs_bicr = obs_bicr,
    obs_pfs_bicr_upper = upper, true_pfs_bicr = true_bicr,
    event_bicr = event_bicr, event_inv = event_inv,
    event_missing = event_missing
  )
}

#' Simulate two-arm BICR PFS data
#'
#' Generates local investigator and BICR progression times using a Gaussian copula
#' with exponential margins, maps latent times to scheduled visits, and introduces
#' local-central assessment discrepancies.
#'
#' @param n_per_arm Number of subjects per treatment arm.
#' @param med_inv Named vector of local investigator medians, names trt and ctl.
#' @param med_bicr Named vector of BICR medians, names trt and ctl.
#' @param rho Correlation on Gaussian copula scale.
#' @param cutoff Administrative cutoff time.
#' @param visit_interval Scheduled assessment interval.
#' @param disagreement Named vector of local-BICR disagreement rates.
#' @param stay Named vector of probabilities of continued scans after local PD.
#' @param seed Optional random seed.
#' @param visit_jitter_sd Standard deviation of visit-time jitter.
#' @return A data frame with one row per subject.
#' @export
simulate_bicr_data <- function(n_per_arm = 300,
                               med_inv = c(trt = 28, ctl = 19),
                               med_bicr = c(trt = 30, ctl = 23),
                               rho = 0.8,
                               cutoff = 100,
                               visit_interval = 6,
                               disagreement = c(trt = 0.6, ctl = 0.3),
                               stay = c(trt = 0.3, ctl = 0.3),
                               seed = NULL,
                               visit_jitter_sd = 1) {
  if (!is.null(seed)) set.seed(seed)
  trt <- .single_arm_bicr(1L, med_inv[["trt"]], med_bicr[["trt"]], rho,
                          n_per_arm, cutoff, visit_interval,
                          disagreement[["trt"]], stay[["trt"]], visit_jitter_sd)
  ctl <- .single_arm_bicr(0L, med_inv[["ctl"]], med_bicr[["ctl"]], rho,
                          n_per_arm, cutoff, visit_interval,
                          disagreement[["ctl"]], stay[["ctl"]], visit_jitter_sd)
  out <- rbind(trt, ctl)
  out$id <- seq_len(nrow(out))
  rownames(out) <- NULL
  out
}

#' Identify subjects with potentially informative BICR censoring
#'
#' @param data Analysis data frame.
#' @param visit_interval Scheduled scan interval.
#' @param time_bicr,event_bicr,time_inv,event_inv Column names.
#' @param tolerance Allowed proximity between BICR censoring time and local PD time.
#' @return Logical vector indicating potentially informative censoring.
#' @export
identify_informative <- function(data,
                                 visit_interval,
                                 time_bicr = "obs_pfs_bicr",
                                 event_bicr = "event_bicr",
                                 time_inv = "obs_pfs_inv",
                                 event_inv = "event_inv",
                                 tolerance = visit_interval / 2) {
  .require_cols(data, c(time_bicr, event_bicr, time_inv, event_inv))
  data[[event_inv]] == 1L & data[[event_bicr]] == 0L &
    data[[time_bicr]] <= data[[time_inv]] + tolerance
}

#' Summarize BICR censoring and discrepancy patterns
#'
#' @param data Analysis data frame.
#' @param visit_interval Scheduled scan interval.
#' @param arm Treatment arm column name.
#' @param time_bicr,event_bicr,time_inv,event_inv,event_missing Column names.
#' @param ... Additional arguments passed to identify_informative.
#' @return Data frame with arm-level diagnostics.
#' @export
censoring_diagnostics <- function(data, visit_interval, arm = "trt",
                                  time_bicr = "obs_pfs_bicr",
                                  event_bicr = "event_bicr",
                                  time_inv = "obs_pfs_inv",
                                  event_inv = "event_inv",
                                  event_missing = "event_missing", ...) {
  .require_cols(data, c(arm, time_bicr, event_bicr, time_inv, event_inv))
  flag <- identify_informative(data, visit_interval = visit_interval,
                               time_bicr = time_bicr, event_bicr = event_bicr,
                               time_inv = time_inv, event_inv = event_inv, ...)
  groups <- sort(unique(data[[arm]]))
  out <- lapply(groups, function(g) {
    idx <- data[[arm]] == g
    n <- sum(idx)
    flagged <- sum(flag[idx], na.rm = TRUE)
    continued <- if (event_missing %in% names(data)) sum(data[[event_missing]][idx] == 1L & flag[idx], na.rm = TRUE) else NA_integer_
    data.frame(
      arm = as.character(g), n = n,
      bicr_events = sum(data[[event_bicr]][idx] == 1L, na.rm = TRUE),
      bicr_censored = sum(data[[event_bicr]][idx] == 0L, na.rm = TRUE),
      local_pd = sum(data[[event_inv]][idx] == 1L, na.rm = TRUE),
      informative = flagged,
      informative_prop = ifelse(n > 0, flagged / n, NA_real_),
      continued_after_local_pd = continued,
      continued_prop_among_informative = ifelse(flagged > 0 && !is.na(continued), continued / flagged, NA_real_),
      row.names = NULL
    )
  })
  do.call(rbind, out)
}

.km_surv_at <- function(sf, times) {
  ans <- summary(sf, times = times, extend = TRUE)$surv
  if (length(ans) == 0L) rep(1, length(times)) else ans
}

#' Conditional restricted mean survival imputation
#'
#' Computes lower plus the area under S(u)/S(lower) from lower to upper.
#'
#' @param time Observed survival times.
#' @param event Event indicators.
#' @param lower Lower bound.
#' @param upper Upper bound.
#' @param eps Small positive number to avoid division by zero.
#' @return Numeric vector of imputed times.
#' @export
cond_surv_mean <- function(time, event, lower, upper, eps = 1e-8) {
  if (length(time) != length(event)) stop("time and event must have the same length", call. = FALSE)
  sf <- survival::survfit(survival::Surv(time, event) ~ 1)
  one_value <- function(l, u) {
    if (is.na(l) || is.na(u)) return(NA_real_)
    if (u <= l) return(l)
    knots <- sort(unique(c(l, u, sf$time[sf$time > l & sf$time < u])))
    if (length(knots) < 2L) return(l)
    left <- knots[-length(knots)]
    right <- knots[-1L]
    s_left <- .km_surv_at(sf, left)
    auc <- sum((right - left) * s_left)
    s_l <- max(.km_surv_at(sf, l), eps)
    l + auc / s_l
  }
  mapply(one_value, lower, upper)
}

.cond_surv_draw <- function(time, event, lower, upper) {
  sf <- survival::survfit(survival::Surv(time, event) ~ 1)
  one_value <- function(l, u) {
    if (is.na(l) || is.na(u) || u <= l) return(l)
    times <- sf$time[sf$time > l & sf$time <= u]
    if (length(times) == 0L) return(cond_surv_mean(time, event, l, u))
    s_l <- max(.km_surv_at(sf, l), 1e-8)
    s_t <- .km_surv_at(sf, times)
    probs <- c(1, s_t[-length(s_t)] / s_l) - s_t / s_l
    probs <- pmax(probs, 0)
    if (sum(probs) <= 0) return(cond_surv_mean(time, event, l, u))
    sample(times, size = 1L, prob = probs)
  }
  mapply(one_value, lower, upper)
}

.impute_arm_once <- function(d, visit_interval, time_bicr, event_bicr, upper_bicr,
                             event_missing, time_inv, event_inv, c1, c2, c3,
                             conditional_method, bootstrap_donors) {
  n <- nrow(d)
  informative <- identify_informative(d, visit_interval, time_bicr, event_bicr,
                                      time_inv, event_inv, c1)
  out_time <- d[[time_bicr]]
  out_event <- d[[event_bicr]]
  impute_type <- rep("none", n)
  donor_size <- rep(NA_integer_, n)

  donor_source <- d
  donor_informative <- informative
  if (isTRUE(bootstrap_donors) && n > 1L) {
    boot_index <- sample.int(n, size = n, replace = TRUE)
    donor_source <- d[boot_index, , drop = FALSE]
    donor_informative <- identify_informative(donor_source, visit_interval,
                                              time_bicr, event_bicr,
                                              time_inv, event_inv, c1)
  }
  riskset <- which(donor_source[[event_inv]] == 1L & !donor_informative)
  has_upper <- !is.null(upper_bicr) && upper_bicr %in% names(d)
  has_missing <- !is.null(event_missing) && event_missing %in% names(d)

  for (i in which(informative)) {
    a0 <- d[[time_inv]][i]
    b0 <- d[[time_bicr]][i]
    is_continued <- has_missing && d[[event_missing]][i] == 1L
    ind <- riskset[donor_source[[time_inv]][riskset] >= a0 - c2 &
                     donor_source[[time_inv]][riskset] <= a0 + c2 &
                     donor_source[[time_bicr]][riskset] >= b0 + c3]
    if (is_continued && has_upper) {
      ind <- ind[donor_source[[time_bicr]][ind] <= d[[upper_bicr]][i]]
    }
    donor_size[i] <- length(ind)
    if (length(ind) > 0L) {
      j <- sample(ind, size = 1L)
      out_time[i] <- donor_source[[time_bicr]][j]
      out_event[i] <- donor_source[[event_bicr]][j]
      impute_type[i] <- if (isTRUE(bootstrap_donors)) "donor_bootstrap" else "donor"
    } else if (is_continued && has_upper) {
      if (conditional_method == "draw") {
        out_time[i] <- .cond_surv_draw(donor_source[[time_bicr]], donor_source[[event_bicr]],
                                       b0, d[[upper_bicr]][i])
      } else {
        out_time[i] <- cond_surv_mean(donor_source[[time_bicr]], donor_source[[event_bicr]],
                                      b0, d[[upper_bicr]][i])
      }
      out_event[i] <- 1L
      impute_type[i] <- "conditional"
    } else {
      impute_type[i] <- "unimputed"
    }
  }
  d$pfs_imputed <- out_time
  d$event_imputed <- out_event
  d$impute_type <- impute_type
  d$donor_size <- donor_size
  d
}

#' Create one imputed BICR PFS data set
#'
#' @param data Analysis data frame.
#' @param visit_interval Scheduled scan interval.
#' @param arm Treatment arm column name.
#' @param time_bicr,event_bicr,upper_bicr,event_missing,time_inv,event_inv Column names.
#' @param c1,c2,c3 Matching tolerances.
#' @param conditional_method Use stochastic conditional draws or conditional mean.
#' @param bootstrap_donors Logical; if TRUE, use bootstrap donor samples.
#' @return Data frame with imputed columns added.
#' @export
impute_once <- function(data,
                        visit_interval,
                        arm = "trt",
                        time_bicr = "obs_pfs_bicr",
                        event_bicr = "event_bicr",
                        upper_bicr = "obs_pfs_bicr_upper",
                        event_missing = "event_missing",
                        time_inv = "obs_pfs_inv",
                        event_inv = "event_inv",
                        c1 = visit_interval / 2,
                        c2 = visit_interval / 2,
                        c3 = visit_interval,
                        conditional_method = c("draw", "mean"),
                        bootstrap_donors = FALSE) {
  conditional_method <- match.arg(conditional_method)
  validate_pfsmi_data(data, time_bicr = time_bicr, event_bicr = event_bicr,
                      time_inv = time_inv, event_inv = event_inv, arm = arm)
  dat <- data
  dat$.orig_order <- seq_len(nrow(dat))
  pieces <- lapply(split(dat, dat[[arm]]), .impute_arm_once,
                   visit_interval = visit_interval,
                   time_bicr = time_bicr, event_bicr = event_bicr,
                   upper_bicr = upper_bicr, event_missing = event_missing,
                   time_inv = time_inv, event_inv = event_inv,
                   c1 = c1, c2 = c2, c3 = c3,
                   conditional_method = conditional_method,
                   bootstrap_donors = bootstrap_donors)
  out <- do.call(rbind, pieces)
  out <- out[order(out$.orig_order), ]
  out$.orig_order <- NULL
  rownames(out) <- NULL
  out
}

#' Donor and imputation diagnostics
#'
#' @param data Analysis data frame.
#' @param visit_interval Scheduled scan interval.
#' @param arm Treatment arm column name.
#' @param ... Additional arguments passed to impute_once.
#' @return List with type counts, donor summary, and diagnostic data.
#' @export
donor_diagnostics <- function(data, visit_interval, arm = "trt", ...) {
  imp <- impute_once(data, visit_interval = visit_interval, arm = arm, ...)
  type_counts <- as.data.frame(table(arm = imp[[arm]], impute_type = imp$impute_type),
                               stringsAsFactors = FALSE)
  flagged <- imp[!is.na(imp$donor_size), c(arm, "donor_size", "impute_type")]
  if (nrow(flagged) == 0L) {
    donor_summary <- data.frame(arm = character(), n_flagged = integer(),
                                mean_donor_size = numeric(), median_donor_size = numeric(),
                                min_donor_size = numeric(), max_donor_size = numeric(),
                                n_zero_donor = integer())
  } else {
    donor_summary <- do.call(rbind, lapply(split(flagged, flagged[[arm]]), function(x) {
      data.frame(
        arm = as.character(x[[arm]][1L]), n_flagged = nrow(x),
        mean_donor_size = mean(x$donor_size, na.rm = TRUE),
        median_donor_size = stats::median(x$donor_size, na.rm = TRUE),
        min_donor_size = min(x$donor_size, na.rm = TRUE),
        max_donor_size = max(x$donor_size, na.rm = TRUE),
        n_zero_donor = sum(x$donor_size == 0, na.rm = TRUE), row.names = NULL)
    }))
    rownames(donor_summary) <- NULL
  }
  list(type_counts = type_counts, donor_summary = donor_summary, data = imp)
}


#' Diagnose BICR multiple imputation support
#'
#' @param data Analysis data frame.
#' @param visit_interval Scheduled scan interval.
#' @param arm Treatment arm column name.
#' @param ... Additional arguments passed to donor_diagnostics.
#' @return List with type counts, donor summary, and diagnostic data.
#' @export
diagnose_imputation <- function(data, visit_interval, arm = "trt", ...) {
  donor_diagnostics(data, visit_interval = visit_interval, arm = arm, ...)
}

.one_imputation_diagnostic <- function(di) {
  .require_cols(di, c("impute_type", "donor_size"))
  donor <- di$donor_size[is.finite(di$donor_size)]
  data.frame(
    n = nrow(di), n_flagged = sum(di$impute_type != "none", na.rm = TRUE),
    n_donor = sum(di$impute_type %in% c("donor", "donor_bootstrap"), na.rm = TRUE),
    n_conditional = sum(di$impute_type == "conditional", na.rm = TRUE),
    n_unimputed = sum(di$impute_type == "unimputed", na.rm = TRUE),
    donor_min = if (length(donor)) min(donor) else NA_real_,
    donor_median = if (length(donor)) stats::median(donor) else NA_real_,
    donor_mean = if (length(donor)) mean(donor) else NA_real_,
    donor_max = if (length(donor)) max(donor) else NA_real_, row.names = NULL)
}

#' Summarize imputation diagnostics
#'
#' @param x Imputed data frame, list of imputed data frames, or mi_bicr object.
#' @return Data frame with imputation counts and donor-size summaries.
#' @export
imputation_diagnostics <- function(x) {
  if (is.list(x) && !is.null(x$imputation_summary)) return(x$imputation_summary)
  if (is.list(x) && !is.null(x$imputed)) x <- x$imputed
  if (is.data.frame(x)) return(.one_imputation_diagnostic(x))
  if (is.list(x) && length(x) > 0L && all(vapply(x, is.data.frame, logical(1)))) {
    out <- do.call(rbind, lapply(seq_along(x), function(i) {
      z <- .one_imputation_diagnostic(x[[i]])
      z$imputation <- i
      z
    }))
    rownames(out) <- NULL
    return(out)
  }
  stop("unsupported input for imputation_diagnostics", call. = FALSE)
}

.median_table <- function(sf) {
  tab <- summary(sf)$table
  if (is.null(dim(tab))) {
    data.frame(group = "all", median = unname(tab["median"]), row.names = NULL)
  } else {
    data.frame(group = rownames(tab), median = tab[, "median"], row.names = NULL)
  }
}

#' Fit standard PFS analyses
#'
#' @param data Analysis data frame.
#' @param time,event,arm Column names for survival time, event indicator, and arm.
#' @param conf_level Confidence level.
#' @return A list containing Cox, log-rank, and median PFS summaries.
#' @export
fit_pfs <- function(data, time = "obs_pfs_bicr", event = "event_bicr",
                    arm = "trt", conf_level = 0.95) {
  .require_cols(data, c(time, event, arm))
  form <- stats::as.formula(paste0("survival::Surv(", time, ", ", event, ") ~ ", arm))
  fit <- survival::coxph(form, data = data, ties = "breslow")
  s <- summary(fit, conf.int = conf_level)
  lr <- survival::survdiff(form, data = data)
  sf <- survival::survfit(form, data = data, conf.type = "log-log", conf.int = conf_level)
  lower_col <- grep("^lower", colnames(s$conf.int), value = TRUE)[1]
  upper_col <- grep("^upper", colnames(s$conf.int), value = TRUE)[1]
  log_hr <- unname(s$coefficients[1, "coef"])
  list(
    cox = data.frame(log_hr = log_hr,
                     log_hr_se = unname(s$coefficients[1, "se(coef)"]),
                     hr = unname(s$conf.int[1, "exp(coef)"]),
                     lower = unname(s$conf.int[1, lower_col]),
                     upper = unname(s$conf.int[1, upper_col]),
                     p = unname(s$coefficients[1, "Pr(>|z|)"])),
    logrank = data.frame(chisq = lr$chisq,
                         signed_z = ifelse(log_hr < 0, -1, 1) * sqrt(lr$chisq),
                         p = stats::pchisq(lr$chisq, df = 1, lower.tail = FALSE)),
    median = .median_table(sf), coxph = fit, survfit = sf)
}

#' Rubin pooling for scalar estimates
#'
#' @param est Vector of point estimates.
#' @param se Vector of standard errors.
#' @param conf_level Confidence level.
#' @return Named numeric vector with pooled estimate, SE, degrees of freedom, p-value, and limits.
#' @export
pool_rubin <- function(est, se, conf_level = 0.95) {
  ok <- is.finite(est) & is.finite(se)
  est <- est[ok]
  se <- se[ok]
  m <- length(est)
  if (m == 0L) stop("no finite estimates to pool", call. = FALSE)
  theta <- mean(est)
  w <- mean(se^2)
  b <- if (m > 1L) stats::var(est) else 0
  total <- w + (1 + 1 / m) * b
  df <- if (b <= .Machine$double.eps) Inf else (m - 1) * (1 + w / ((1 + 1 / m) * b))^2
  stat <- theta / sqrt(total)
  p <- 2 * stats::pt(abs(stat), df = df, lower.tail = FALSE)
  q <- stats::qt(0.5 + conf_level / 2, df = df)
  c(est = theta, se = sqrt(total), statistic = stat, df = df, p = p,
    lower = theta - q * sqrt(total), upper = theta + q * sqrt(total),
    within = w, between = b)
}

.surv_prob_one <- function(data, times, arm = "trt", time = "pfs_imputed", event = "event_imputed") {
  form <- stats::as.formula(paste0("survival::Surv(", time, ", ", event, ") ~ ", arm))
  sf <- survival::survfit(form, data = data)
  out <- lapply(seq_along(sf$strata), function(k) {
    nm <- names(sf$strata)[k]
    idx_start <- if (k == 1L) 1L else sum(sf$strata[seq_len(k - 1L)]) + 1L
    idx_end <- sum(sf$strata[seq_len(k)])
    sf_k <- sf
    sf_k$time <- sf$time[idx_start:idx_end]
    sf_k$surv <- sf$surv[idx_start:idx_end]
    sm <- summary(sf_k, times = times, extend = TRUE)
    data.frame(group = nm, time = times, survival = sm$surv,
               se = if (!is.null(sm$std.err)) sm$std.err else NA_real_, row.names = NULL)
  })
  do.call(rbind, out)
}

.pool_survival_prob <- function(surv, se, conf_level = 0.95, eps = 1e-6) {
  surv <- pmin(pmax(surv, eps), 1 - eps)
  y <- log(-log(surv))
  dy <- se / (pmax(surv * abs(log(surv)), eps))
  pp <- pool_rubin(y, dy, conf_level = conf_level)
  c(survival = exp(-exp(pp["est"])), lower = exp(-exp(pp["upper"])), upper = exp(-exp(pp["lower"])))
}

#' Pool survival probabilities on the log-log scale
#'
#' @param surv Vector of survival probability estimates.
#' @param se Vector of standard errors on probability scale.
#' @param conf_level Confidence level.
#' @return Named vector with pooled survival and limits.
#' @export
pool_survival_prob <- function(surv, se, conf_level = 0.95) {
  .pool_survival_prob(surv, se, conf_level = conf_level)
}

.median_summary <- function(medians) {
  med <- do.call(rbind, medians)
  groups <- unique(med$group)
  out <- do.call(rbind, lapply(groups, function(g) {
    x <- med$median[med$group == g]
    data.frame(group = g, median_mean = mean(x, na.rm = TRUE),
               median_sd = stats::sd(x, na.rm = TRUE),
               median_n = sum(is.finite(x)), row.names = NULL)
  }))
  rownames(out) <- NULL
  out
}

#' Multiple imputation analysis for BICR PFS
#'
#' @param data Analysis data frame.
#' @param m Number of imputations.
#' @param visit_interval Scheduled scan interval.
#' @param seed Optional random seed.
#' @param keep_imputed Return imputed data sets.
#' @param arm Treatment arm column name.
#' @param times Optional times for pooled survival probabilities.
#' @param conf_level Confidence level.
#' @param bootstrap_donors Logical; if TRUE, use bootstrap donor samples.
#' @param ... Additional arguments passed to impute_once.
#' @return List with pooled Cox, signed log-rank, survival, median, estimates, diagnostics, and imputed data.
#' @export
mi_bicr <- function(data, m = 100, visit_interval, seed = NULL,
                    keep_imputed = FALSE, arm = "trt", times = NULL,
                    conf_level = 0.95, bootstrap_donors = TRUE, ...) {
  if (!is.null(seed)) set.seed(seed)
  estimates <- matrix(NA_real_, nrow = m, ncol = 4)
  colnames(estimates) <- c("log_hr", "log_hr_se", "signed_logrank_z", "logrank_se")
  medians <- vector("list", m)
  surv_probs <- list()
  imputed <- if (keep_imputed) vector("list", m) else NULL
  imputation_summaries <- vector("list", m)
  for (k in seq_len(m)) {
    di <- impute_once(data, visit_interval = visit_interval, arm = arm,
                      bootstrap_donors = bootstrap_donors, ...)
    fa <- fit_pfs(di, time = "pfs_imputed", event = "event_imputed", arm = arm,
                  conf_level = conf_level)
    estimates[k, "log_hr"] <- fa$cox$log_hr
    estimates[k, "log_hr_se"] <- fa$cox$log_hr_se
    estimates[k, "signed_logrank_z"] <- fa$logrank$signed_z
    estimates[k, "logrank_se"] <- 1
    medians[[k]] <- fa$median
    if (!is.null(times)) surv_probs[[k]] <- .surv_prob_one(di, times = times, arm = arm)
    imputation_summaries[[k]] <- .one_imputation_diagnostic(di)
    imputation_summaries[[k]]$imputation <- k
    if (keep_imputed) imputed[[k]] <- di
  }
  pooled_log_hr <- pool_rubin(estimates[, "log_hr"], estimates[, "log_hr_se"], conf_level)
  pooled_hr <- pooled_log_hr
  pooled_hr[c("est", "lower", "upper")] <- exp(pooled_hr[c("est", "lower", "upper")])
  names(pooled_hr)[names(pooled_hr) == "est"] <- "hr"
  pooled_z <- pool_rubin(estimates[, "signed_logrank_z"], estimates[, "logrank_se"], conf_level)
  pooled_surv <- NULL
  if (!is.null(times)) {
    surv_all <- do.call(rbind, surv_probs)
    keys <- unique(surv_all[, c("group", "time")])
    pooled_surv <- do.call(rbind, lapply(seq_len(nrow(keys)), function(i) {
      tmp <- surv_all[surv_all$group == keys$group[i] & surv_all$time == keys$time[i], ]
      pp <- .pool_survival_prob(tmp$survival, tmp$se, conf_level)
      data.frame(group = keys$group[i], time = keys$time[i], survival = pp["survival"],
                 lower = pp["lower"], upper = pp["upper"], row.names = NULL)
    }))
  }
  imputation_summary <- do.call(rbind, imputation_summaries)
  rownames(imputation_summary) <- NULL
  list(cox = pooled_hr, log_hr = pooled_log_hr, signed_logrank = pooled_z,
       surv_prob = pooled_surv, median = .median_summary(medians), estimates = estimates,
       diagnostics = donor_diagnostics(data, visit_interval = visit_interval, arm = arm,
                                       bootstrap_donors = bootstrap_donors, ...),
       imputation_summary = imputation_summary, imputed = imputed)
}

#' Next-visit sensitivity analysis
#'
#' @param data Analysis data frame.
#' @param visit_interval Scheduled scan interval.
#' @param schedule Optional vector of scheduled visit times.
#' @param time_bicr,event_bicr,event_inv Column names.
#' @param ... Arguments passed to identify_informative.
#' @return Data frame with sensitivity time and event columns.
#' @export
sensitivity_next_visit <- function(data, visit_interval, schedule = NULL,
                                   time_bicr = "obs_pfs_bicr",
                                   event_bicr = "event_bicr",
                                   event_inv = "event_inv", ...) {
  out <- data
  idx <- identify_informative(data, visit_interval = visit_interval,
                              time_bicr = time_bicr, event_bicr = event_bicr,
                              event_inv = event_inv, ...)
  next_time <- data[[time_bicr]] + visit_interval
  if (!is.null(schedule)) {
    schedule <- sort(schedule)
    next_time[idx] <- vapply(data[[time_bicr]][idx], function(x) {
      y <- schedule[schedule > x]
      if (length(y) == 0L) x + visit_interval else y[1L]
    }, numeric(1))
  }
  out$pfs_sensitivity <- data[[time_bicr]]
  out$event_sensitivity <- data[[event_bicr]]
  out$pfs_sensitivity[idx] <- next_time[idx]
  out$event_sensitivity[idx] <- 1L
  out
}

#' Run a grid of deterministic local-PD sensitivity analyses
#'
#' @param data Analysis data frame.
#' @param visit_interval Scheduled scan interval.
#' @param delays Numeric vector of delays added to the BICR censoring time.
#' @param time_bicr,event_bicr Column names.
#' @param ... Additional arguments passed to identify_informative.
#' @return Data frame of Cox estimates for each delay.
#' @export
sensitivity_grid <- function(data, visit_interval,
                             delays = c(0, visit_interval / 2, visit_interval, 2 * visit_interval),
                             time_bicr = "obs_pfs_bicr", event_bicr = "event_bicr", ...) {
  out <- lapply(delays, function(delay) {
    d <- data
    flag <- identify_informative(d, visit_interval = visit_interval,
                                 time_bicr = time_bicr, event_bicr = event_bicr, ...)
    d$pfs_sensitivity_grid <- d[[time_bicr]]
    d$event_sensitivity_grid <- d[[event_bicr]]
    d$pfs_sensitivity_grid[flag] <- d[[time_bicr]][flag] + delay
    d$event_sensitivity_grid[flag] <- 1L
    fit <- fit_pfs(d, time = "pfs_sensitivity_grid", event = "event_sensitivity_grid")$cox
    data.frame(delay = delay, fit, row.names = NULL)
  })
  do.call(rbind, out)
}

.predict_censor_surv <- function(cfit, dat, time) {
  vapply(seq_len(nrow(dat)), function(i) {
    sf_i <- survival::survfit(cfit, newdata = dat[i, , drop = FALSE])
    s <- summary(sf_i, times = dat[[time]][i], extend = TRUE)$surv
    if (length(s) == 0L) 1 else as.numeric(s[1L])
  }, numeric(1))
}

#' Simple IPCW Cox comparator
#'
#' @param data Analysis data frame.
#' @param time,event,arm Column names.
#' @param censor_covariates Character vector of covariates for the censoring model.
#' @param stabilized Use stabilized weights.
#' @param truncate Optional upper quantile for weight truncation.
#' @return List with weighted Cox fit, censoring model, weights, raw weights, and data.
#' @export
ipcw_cox <- function(data, time = "obs_pfs_bicr", event = "event_bicr",
                     arm = "trt", censor_covariates = arm,
                     stabilized = TRUE, truncate = 0.99) {
  .require_cols(data, c(time, event, arm, censor_covariates))
  dat <- data
  dat$.censor_event <- 1L - dat[[event]]
  aform <- stats::as.formula(paste0("survival::Surv(", time, ", ", event, ") ~ ", arm))
  if (sum(dat$.censor_event, na.rm = TRUE) == 0L) {
    dat$.ipcw <- rep(1, nrow(dat))
    afit <- survival::coxph(aform, data = dat, weights = .ipcw, robust = TRUE, ties = "breslow")
    return(list(fit = afit, censor_model = NULL, weights = dat$.ipcw,
                raw_weights = dat$.ipcw, truncated = rep(FALSE, nrow(dat)),
                cap = NA_real_, data = dat))
  }
  cform <- stats::as.formula(paste0("survival::Surv(", time, ", .censor_event) ~ ",
                                    paste(censor_covariates, collapse = " + ")))
  cfit <- survival::coxph(cform, data = dat, ties = "breslow")
  gz <- pmax(.predict_censor_surv(cfit, dat, time), 1e-6)
  g0fit <- survival::survfit(stats::as.formula(paste0("survival::Surv(", time,
                                                       ", .censor_event) ~ 1")), data = dat)
  g0 <- summary(g0fit, times = dat[[time]], extend = TRUE)$surv
  raw_weights <- if (stabilized) g0 / gz else 1 / gz
  weights <- raw_weights
  cap <- NA_real_
  truncated <- rep(FALSE, length(weights))
  if (!is.null(truncate)) {
    cap <- stats::quantile(weights, probs = truncate, na.rm = TRUE, names = FALSE)
    truncated <- weights > cap
    weights <- pmin(weights, cap)
  }
  attr(weights, "truncation_cap") <- cap
  dat$.ipcw <- weights
  afit <- survival::coxph(aform, data = dat, weights = .ipcw, robust = TRUE, ties = "breslow")
  list(fit = afit, censor_model = cfit, weights = weights, raw_weights = raw_weights,
       truncated = truncated, cap = cap, stabilized = stabilized, data = dat)
}

#' Summarize IPCW weights
#'
#' @param x Object returned by ipcw_cox or a numeric vector of weights.
#' @return One-row data frame with weight diagnostics.
#' @export
ipcw_diagnostics <- function(x) {
  if (is.list(x) && !is.null(x$weights)) {
    w <- x$weights
    trunc <- if (!is.null(x$truncated)) x$truncated else rep(FALSE, length(w))
    cap <- if (!is.null(x$cap)) x$cap else attr(w, "truncation_cap", exact = TRUE)
  } else {
    w <- x
    trunc <- rep(FALSE, length(w))
    cap <- attr(w, "truncation_cap", exact = TRUE)
  }
  if (!is.numeric(w)) stop("x must contain numeric weights", call. = FALSE)
  q <- stats::quantile(w, probs = c(0, 0.25, 0.5, 0.75, 0.95, 0.99, 1),
                       na.rm = TRUE, names = FALSE)
  data.frame(n = length(w), mean = mean(w, na.rm = TRUE), sd = stats::sd(w, na.rm = TRUE),
             min = q[1], q25 = q[2], median = q[3], q75 = q[4], q95 = q[5],
             q99 = q[6], max = q[7], cap = if (is.null(cap)) NA_real_ else cap,
             n_truncated = sum(trunc, na.rm = TRUE), row.names = NULL)
}

#' Summarize Monte Carlo simulation output
#'
#' @param results A list of named numeric vectors or data frames from repeated runs.
#' @return Data frame with means and standard deviations for numeric columns.
#' @export
summarize_simulation <- function(results) {
  dat <- do.call(rbind, lapply(results, function(x) as.data.frame(as.list(x))))
  num <- vapply(dat, is.numeric, logical(1))
  data.frame(variable = names(dat)[num],
             mean = vapply(dat[num], function(x) mean(x, na.rm = TRUE), numeric(1)),
             sd = vapply(dat[num], function(x) stats::sd(x, na.rm = TRUE), numeric(1)),
             row.names = NULL)
}
