test_that("simulation, validation, and primary fit work", {
  dat <- simulate_bicr_data(n_per_arm = 20, seed = 1)
  expect_equal(nrow(dat), 40)
  expect_true(validate_pfsmi_data(dat))
  fit <- fit_pfs(dat)
  expect_true(is.finite(fit$cox$hr))
})

test_that("imputation and diagnostics add expected columns", {
  dat <- simulate_bicr_data(n_per_arm = 20, seed = 2)
  imp <- impute_once(dat, visit_interval = 6)
  expect_true(all(c("pfs_imputed", "event_imputed", "impute_type", "donor_size") %in% names(imp)))
  dx <- donor_diagnostics(dat, visit_interval = 6)
  expect_true(all(c("type_counts", "donor_summary", "data") %in% names(dx)))
})

test_that("extended diagnostics and sensitivity helpers return data frames", {
  dat <- simulate_bicr_data(n_per_arm = 20, seed = 3)
  expect_true(validate_bicr_data(dat))
  cd <- censoring_diagnostics(dat, visit_interval = 6)
  expect_true(is.data.frame(cd))
  imp <- impute_once(dat, visit_interval = 6, bootstrap_donors = TRUE)
  expect_true(is.data.frame(imputation_diagnostics(imp)))
  sg <- sensitivity_grid(dat, visit_interval = 6, delays = c(0, 6))
  expect_true(is.data.frame(sg))
})

test_that("survival pooling and MI summaries return expected components", {
  pp <- pool_survival_prob(c(0.6, 0.65, 0.62), c(0.05, 0.05, 0.06))
  expect_true(all(c("survival", "lower", "upper") %in% names(pp)))
  dat <- simulate_bicr_data(n_per_arm = 20, seed = 4)
  mi <- mi_bicr(dat, m = 3, visit_interval = 6, seed = 10, times = c(12))
  expect_true(all(c("cox", "surv_prob", "diagnostics") %in% names(mi)))
})
